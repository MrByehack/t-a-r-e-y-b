﻿$rate = 100000
$RecommendedNumberOfScanners = 10
$folderMasscan			= 'C:\Massscan'
$fileMasscanIPs			= "$folderMasscan\IPs.txt"

function go_masscan {
    Set-Location $folderMasscan
    Clear-Content $fileMasscanIPs
    [int]$num = $RecommendedNumberOfScanners
    $ipPorts = Get-Content "$folderMasscan\InputPort.txt"
    $Outf = @()

    Write-host "Masscan запущен: (port:$ipPorts)"
      for ( $n = $num; $n -ge 1; $n-- ) {
      $trueRate = $rate/$num
        Start-Process masscan.exe -ArgumentList "-c masscan.conf -iL InputRange.txt -p $ipPorts --shard $n`/$num -oB $env:TEMP\Out_$n --rate=$trueRate"
        $Outf += "$env:TEMP\Out_$n"
        Start-Sleep -Milliseconds 500
        }
    $BinF = $Outf -join ","

    While ((Get-Process -Name masscan -ErrorAction SilentlyContinue)) {
        Start-Sleep 1
        }
    Start-Process masscan.exe -ArgumentList "--readscan $Outf -oL Output.txt" -Wait

    $awkId = (Start-Process awkparseips.bat -PassThru ).Id
    While ((Get-Process -Id $awkId -ErrorAction SilentlyContinue)) {
        Start-Sleep 1
        }
} # end of goMasscan
go_masscan 